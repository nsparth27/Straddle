# Dhan Straddle Pro — Bloomberg Terminal & Real-Time Breakout Engine

Real-time F&O and MCX Commodity ATM Straddle Breakout Engine with automated Previous Day High (PDH) tracking and Telegram notification dispatch.

## 🚀 Instant Cloud Deployment (Render.com)

1. Fork or upload this repository to GitHub.
2. Go to [Render.com](https://render.com) and create a **New Web Service**.
3. Connect your GitHub repository.
4. Set the following settings:
   - **Environment:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Plan:** `Free`
5. Click **Create Web Service**.

### ⏱️ Keep Alive 24x7 (Prevent Sleeping):
Add your Render app URL (`https://<your-app>.onrender.com/api/status`) to a free 5-minute cron on [cron-job.org](https://cron-job.org) or [UptimeRobot](https://uptimerobot.com).

## 💻 Local Quickstart

```bash
npm install
npm start
```
Open [http://localhost:3000](http://localhost:3000) in your browser.
